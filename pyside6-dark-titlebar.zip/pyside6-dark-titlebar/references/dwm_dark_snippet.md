# Darken the native title bar on Windows (PySide6 / Qt for Python)

The native window title bar is painted by Windows (DWM), not Qt, so QSS
`background` on the window has no effect. To make it dark, ask DWM via
`DwmSetWindowAttribute` with the undocumented dark-mode attribute.

## Working snippet

```python
def apply_dark_title_bar(self):
    """Paint the native title bar dark to match a dark theme.

    No-op on non-Windows / headless builds (wrapped in try/except).
    """
    try:
        import ctypes
        from ctypes import c_int, byref, sizeof
        hwnd = int(self.winId())
    except Exception:
        return
    try:
        dwm = ctypes.windll.dwmapi
    except Exception:
        return
    # 20 = DWMWA_USE_IMMERSIVE_DARK_MODE (Windows 10 1809+)
    # 38 = Win11 dark-title-bar attribute (same effect, newer builds)
    value = c_int(1)
    for attr in (20, 38):
        try:
            dwm.DwmSetWindowAttribute(
                hwnd, attr, byref(value), sizeof(value))
        except Exception:
            pass
```

## Where to call it

- Once after the UI is built (the `winId()` call forces HWND creation):
  `self._apply_dark_title_bar()` at the end of `__init__`.
- Again from a `showEvent` override, because the HWND is most stable
  once the window is actually shown:

  ```python
  def showEvent(self, e):
      super().showEvent(e)
      self._apply_dark_title_bar()
  ```

## Notes / gotchas

- Both `20` and `38` are set defensively; older Windows ignores the
  one it doesn't know. `try/except` around each keeps it safe.
- This requires the app to have a real native window (i.e. do NOT use
  `Qt.FramelessWindowHint`). If the window is frameless there is no
  native title bar to darken — and frameless + custom drag is what
  breaks child-widget clicks. Keep the native window.
- On a light Windows theme the native title bar may still render light;
  the DWM dark attribute reliably forces dark on Win10 1809+ / Win11.
- `winId()` returns a `sip.voidptr`; `int(...)` gives the `HWND`
  that `DwmSetWindowAttribute` expects.
