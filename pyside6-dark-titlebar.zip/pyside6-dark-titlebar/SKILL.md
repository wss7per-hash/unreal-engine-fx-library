---
name: pyside6-dark-titlebar
description: "Use this skill when building a PySide6 (Qt for Python) desktop app on Windows and the user wants a dark-themed window, especially a dark title bar, or complains that buttons, filter dropdowns or tag chips stopped working after a custom window chrome was added. It documents the critical pitfall of faking a title bar with Qt.FramelessWindowHint plus custom mouse-drag handlers, which silently steals clicks from child widgets, and the correct fix: keep the native window and darken the title bar via the Windows DWM API."
agent_created: true
---

# PySide6 Dark Title Bar — the Frameless trap

## When to use

- Building/repairing a PySide6 Windows app with a dark theme.
- User reports a white title bar and wants it dark.
- User reports that **after a custom window-chrome change**, buttons/filter
  dropdowns/tag chips/folder trees "stopped working" or "clicks do nothing"
  — even though the handlers are correctly wired.
- You are tempted to use `Qt.FramelessWindowHint` to hide the native
  title bar.

## The trap (root cause of "all my clicks broke")

A common (but broken) pattern: hide the native title bar with
`Qt.FramelessWindowHint`, then draw a custom `QFrame` title bar and
rewrite `mousePressEvent` / `mouseMoveEvent` on the `QMainWindow` to
fake drag-to-move and edge-resize.

**Why it fails:** intercepting mouse events at the `QMainWindow` level to
detect "drag from blank area" is fundamentally fragile. Any heuristic
(`childAt()`, objectName allowlists, interactive-widget blacklists) that
decides "is this press a drag or a click" will eventually misclassify a
real click on a child widget (a `QComboBox` in the toolbar, a `QPushButton`
tag chip, a `QTreeWidget`) as a window-drag and `return` early **without
calling `super().mousePressEvent(e)`**, swallowing the click. Symptoms
appear/disappear unpredictably and are extremely hard to reproduce headlessly
because `QTest.mouseClick(widget, ...)` dispatches directly to the target
widget and never routes through the parent's `mousePressEvent`.

This exact bug caused a multi-round "whack-a-mole" where filter/tag/folder
functionality kept breaking. The fix is architectural, not heuristic.

## The correct fix

1. **Keep the native window.** Do NOT set `Qt.FramelessWindowHint`.
   Native chrome gives correct, OS-handled drag/resize/minimize/maximize/
   close — child-widget clicks can never be intercepted because the main
   window defines **no** mouse-event override at all.
2. **Darken the native title bar with the Windows DWM API** via `ctypes`
   (see `references/dwm_dark_snippet.md`). Set the undocumented dark-mode
   window attribute (value `20` for Win10 1809+, value `38` for Win11)
   on the window's `HWND` after it exists. Wrap everything in `try/except`
   so non-Windows / headless builds silently no-op.
3. **Verify structurally, not just by eye.** Assert that `MainWindow` does
   **not** define its own `mousePressEvent` (check
   `"mousePressEvent" in MainWindow.__dict__` is `False`) and that
   `win.windowFlags() & Qt.FramelessWindowHint == 0`. Then simulate
   real `QTest` clicks on the actual tag chip / filter combo / folder item
   and assert the grid filters — see the test approach below.

## Test approach (how to prove clicks really work)

Headless `QTest.mouseClick(widget, Qt.LeftButton)` sends the event
directly to the widget, so it does NOT exercise a parent's
`mousePressEvent`. To prove a frameless-drag bug is gone, assert the
*absence* of the override (point 3 above) — that is the structural
guarantee. Then separately confirm the handlers fire by dispatching real
clicks and checking state (`_active_tag` set, grid `total_count()` drops,
`_current_folder` set).

## Rules of thumb

- Native window + DWM dark title bar is the professional, reliable solution.
- Never fake title-bar dragging with main-window mouse events.
- If a dark custom title bar is truly required (e.g. a borderless kiosk UI),
  isolate drag handling to ONE widget via an event filter on that specific
  passive widget only — never intercept at the `QMainWindow`.
- PyInstaller `exclude_binaries=True` + `COLLECT` emits a **directory**
  (exe + `_internal/`), not a single file — copy the whole directory when
  distributing.
